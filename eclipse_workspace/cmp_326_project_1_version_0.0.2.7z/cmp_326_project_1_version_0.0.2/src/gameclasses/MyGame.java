package gameclasses;

import gameinterfaces.Game;
import java.util.Scanner;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;

public class MyGame implements Game {
	
	private MyPlayer player;
	protected MyRoom[] dungeon;
	
	public MyGame() throws FileNotFoundException, IOException, NullPointerException {
		// Read PlayerInfo.txt and assign values to player		
		/* Open file */
		Scanner sin = null; // Will read the file and get a value.
		File file = null;

		try {
			file = new File("src/sourcefiles/PlayerInfo.txt"); //assign file location
			if(!file.exists()) // Check if file exists
				sep(file.getName()+" does not exists.");
			sin = new Scanner(file);
			this.player = new MyPlayer(sin.nextLine(), sin.nextLine(), sin.nextInt(), 
					sin.nextInt(), sin.nextInt());
		}catch (FileNotFoundException e) {
			sep(player.toString() + e.getMessage());
		}finally {
			sop(sin);
			if(sin != null)
				sin.close();
		}	
		/* End of file reading */
		
		this.dungeon = new MyRoom[3];
		
		MyMonster monster1 = new MyMonster("Orc", "Covered with green blood", 20, 5, 0);
		MyRoom room1 = new MyRoom(0, "A room with an unbearable smell", monster1);
		MyMonster monster2 = new MyMonster("Skeleton", "Funny how it moves", 40, 10, 10);
		MyRoom room2 = new MyRoom(1, "Dark and cold", monster2); 
		MyMonster monster3 = new MyMonster("Fire Dragon", "Spout fire with each breath", 100, 20, 40);
		MyTreasureRoom room3 = new MyTreasureRoom(2, "A giant hall with something shiny on the other end", 
				monster3, "A large pile of gold");
		
		this.dungeon[0] = room1;
		this.dungeon[1] = room2;
		this.dungeon[2] = room3;
	}
	
	@Override
	public void play() {
		/* file open */
		MyBattle fight;
		MyTreasureRoom tr = (MyTreasureRoom) dungeon[dungeon.length-1];
		PrintWriter sout = null;
		File file = null;
		
		try {
			file = new File("src/sourcefiles/GameLog.txt");
			
			sout = new PrintWriter(new FileOutputStream(file));
			if(!file.exists()) // Check if file exists
				sep(file.getName()+" does not exists.");
			
			sout.println(player.getName()); // Write player's name on file
			
			for(int i = 0; i < this.dungeon.length; i++){
				if(!dungeon[i].isComplete()) {
					if(i == dungeon.length-1) {
						sop("room 3");
						tr.enter(player);
						fight = new MyBattle(player, tr.monster);
					}else {
						sop("room "+(i+1));
						dungeon[i].enter(player);
						fight = new MyBattle(player, dungeon[i].monster);
					}
					fight.run();
				}
				
				if(dungeon[i].isComplete())
					sout.println("Room " + (i+1)+ " cleared");
				
				if(!player.isAlive()) {
					sout.println(player.getName() + " died...");
					sop(player.getName() + " died...");
					break;
				}
				if(tr.isComplete()) {
					sout.println("Treasure room " + (i+1)+ " cleared");
					tr.enter(player);
				}
			}
			sout.println("THE END");
			sout.close();
		} catch (FileNotFoundException e) {
			sep(e.getMessage());
		}finally {
			if(sout != null)
				sout.close();
			sop("THE END");
		}
		/* file close */
	}
	
	public static void main(String[] args) throws NullPointerException, IOException {
		MyGame game = new MyGame();
		game.play();
	}
	
	public static void sep(Object obj) {
		System.err.println(obj);
	}
	
	public static void sop(Object obj) {
		System.out.println(obj);
	}

}
