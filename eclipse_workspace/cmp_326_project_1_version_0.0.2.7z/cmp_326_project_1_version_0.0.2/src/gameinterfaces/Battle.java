package gameinterfaces;

public interface Battle {

	public void run();
	
}
