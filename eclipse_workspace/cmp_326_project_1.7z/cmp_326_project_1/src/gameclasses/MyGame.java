package gameclasses;

import gameinterfaces.Game;
import java.util.Scanner;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class MyGame implements Game{
	
	private MyPlayer player;
	protected MyRoom[] dungeon;
	
	public MyGame() {
		// Read PlayerInfo.txt and assign values to player
		Scanner inFS = null;
		try {
			inFS = new Scanner(new FileInputStream("src/sourcefiles/PlayerInfo.txt"));
		}catch(FileNotFoundException e) {
			MyCreature.sop("There is no such file or directory");
		}
		this.player = new MyPlayer(inFS.nextLine(), inFS.nextLine(), inFS.nextInt(), inFS.nextInt(), 
				inFS.nextInt());
		MyCreature.sop(player.toString());
		inFS.close();
		/* End of file reading */
		
		this.dungeon = new MyRoom[3];
		
		MyMonster monster1 = new MyMonster("Orc", "Covered with green blood", 20, 5, 0);
		MyRoom room1 = new MyRoom(0, "A room with an unbearable smell", monster1);
		MyMonster monster2 = new MyMonster("Skeleton", "Funny how it moves", 40, 10, 10);
		MyRoom room2 = new MyRoom(1, "Dark and cold", monster2); 
		MyMonster monster3 = new MyMonster("Fire Dragon", "Spout fire with each breath", 100, 20, 40);
		MyTreasureRoom room3 = new MyTreasureRoom(2, "A giant hall with something shiny on the other end", 
				monster3, "A large pile of gold");
		
		this.dungeon[0] = room1;
		this.dungeon[1] = room2;
		this.dungeon[2] = room3;
	}
	
	@Override
	public void play() {
		MyBattle fight;
		MyTreasureRoom tr = (MyTreasureRoom) dungeon[dungeon.length-1];
		
		for(int i = 0; i < this.dungeon.length; i++){
			MyCreature.sop("i="+i);
			if(!dungeon[i].isComplete()) {
				if(i == dungeon.length-1) {
					tr.enter(player);
					fight = new MyBattle(player, tr.monster);
				}else {
					dungeon[i].enter(player);
					fight = new MyBattle(player, dungeon[i].monster);
				}
				fight.run();
			}
			
			if(!player.isAlive()) {
				MyCreature.sop(player.getName() + " died...");
				break;
			}
			if(tr.isComplete())
				tr.enter(player);
		}
		MyCreature.sop("End Game");
	}
	
	public static void main(String[] args) {
		MyGame game = new MyGame();
		game.play();
	}

}
