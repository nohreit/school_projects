package gameclasses;

import gameinterfaces.Game;
import java.util.Scanner;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;

public class MyGame implements Game {
	
	private MyPlayer player;
	protected MyRoom[] dungeon;
	
	public MyGame() throws FileNotFoundException, IOException, NullPointerException {
		// Read PlayerInfo.txt and assign values to player
		Scanner inFS = null;
		try {
			inFS = new Scanner(new FileInputStream("src/sourcefiles/PlayerInfo.txt"));
		}catch(FileNotFoundException e) {
			MyCreature.sop("There is no such file or directory");
			e.printStackTrace();
		}
		
		this.player = new MyPlayer(inFS.nextLine(), inFS.nextLine(), inFS.nextInt(), 
				inFS.nextInt(), inFS.nextInt());
		MyCreature.sop(player.toString());
		inFS.close();
		/* End of file reading */
		
		this.dungeon = new MyRoom[3];
		
		MyMonster monster1 = new MyMonster("Orc", "Covered with green blood", 20, 5, 0);
		MyRoom room1 = new MyRoom(0, "A room with an unbearable smell", monster1);
		MyMonster monster2 = new MyMonster("Skeleton", "Funny how it moves", 40, 10, 10);
		MyRoom room2 = new MyRoom(1, "Dark and cold", monster2); 
		MyMonster monster3 = new MyMonster("Fire Dragon", "Spout fire with each breath", 100, 20, 40);
		MyTreasureRoom room3 = new MyTreasureRoom(2, "A giant hall with something shiny on the other end", 
				monster3, "A large pile of gold");
		
		this.dungeon[0] = room1;
		this.dungeon[1] = room2;
		this.dungeon[2] = room3;
	}
	
	@Override
	public void play() {
		MyBattle fight;
		MyTreasureRoom tr = (MyTreasureRoom) dungeon[dungeon.length-1];
		
		//Create file if not exist or load it
		
		PrintWriter outFS = null;
		try {
			outFS = new PrintWriter(new FileOutputStream("src/sourcefiles/GameLog.txt"));
		} catch (FileNotFoundException e) {
			MyCreature.sop("There is no such file or directory");
			e.printStackTrace();
		}

		
		outFS.println(player.getName());
		for(int i = 0; i < this.dungeon.length; i++){
			if(!dungeon[i].isComplete()) {
				if(i == dungeon.length-1) {
					MyCreature.sop("room 3");
					tr.enter(player);
					fight = new MyBattle(player, tr.monster);
				}else {
					MyCreature.sop("room "+(i+1));
					dungeon[i].enter(player);
					fight = new MyBattle(player, dungeon[i].monster);
				}
				fight.run();
			}
			
			if(dungeon[i].isComplete())
				outFS.println("Room " + (i+1)+ " cleared");
			
			if(!player.isAlive()) {
				outFS.println(player.getName() + " died...");
				MyCreature.sop(player.getName() + " died...");
				break;
			}
			if(tr.isComplete()) {
				outFS.println("Treasure room " + (i+1)+ " cleared");
				tr.enter(player);
			}
		}
		outFS.println("THE END");
		MyCreature.sop("End Game");
		outFS.close();
	}
	
	public static void main(String[] args) throws NullPointerException, IOException {
		MyGame game = new MyGame();
		game.play();
		
		String str = "Hello\nWorld\nAra\nAra\n";
		MyCreature.sop(str);
	}

}
