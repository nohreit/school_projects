package Project1;

public class Employee extends Person {

	public String deptName;
	private static int numEmployees;
	private int employeeID; //wdym by generated
	
	public Employee() {
		this.deptName="";
		this.employeeID=0;
		numEmployees++;
	}
	
	public Employee(String dn) {
		this.deptName=dn;
		numEmployees++;
	}
	
	public Employee(String name, int birthYear, String deptName) {
		super(name,birthYear);
		this.deptName=deptName;
		numEmployees++;
	}
	
	public String getDeptName() {
		return deptName;
	}
	
	public static int getNumEmployees() {
		return numEmployees;
	}
	
	private int getEmployeeID() {
		return employeeID;
	}
	
	public void setDeptName(String dept) {
		this.deptName=dept;
	}
	
	@Override
	public boolean equals(Object e) {
		if(e instanceof Employee) {
			Employee otherEmployee= (Employee)e;
			if(super.equals(otherEmployee)) {
				if(this.deptName == otherEmployee.deptName) {
					if(this.employeeID == otherEmployee.employeeID) {
						return true;
					}
				}
			}
		} return false;
	}
	
	@Override
	public String toString() {
		String s= super.toString() + String.format("Employee: Department: %20s | Employee Number: %3d",
				deptName, employeeID);
		return s;
	}
	
	//compareTo
}
