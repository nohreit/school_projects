package Project1;

public class Course {

	public boolean isGraduateCourse;
	public int courseNum;
	public String courseDept;
	public int numCredits;
	
	public Course(boolean graduate, int num, String dept, int credits) {
		this.isGraduateCourse= graduate;
		this.courseNum= num;
		this.courseDept= dept;
		this.numCredits= credits;
	}
	
	public boolean isGraduateCourse() {
		return isGraduateCourse;
	}
	
	public int getCourseNum() {
		return courseNum;
	}
	
	public String getCourseDept() {
		return courseDept;
	}
	
	public int getNumCredits() {
		return numCredits;
	}
	
	public String getCourseName() {
		String s= "";
		if(isGraduateCourse == true) {
			s += "G"+ courseDept+courseNum;
			return s;
		}
		else {
			s += "U"+courseDept+courseNum;
			return s;
		}
	}
	
	public boolean equals(Object obj) {
		if(obj instanceof Course) {
			Course otherCourse= (Course)obj;
			if(this.isGraduateCourse == otherCourse.isGraduateCourse) {
				if(this.courseDept == otherCourse.courseDept) {
					if(this.courseNum == otherCourse.courseNum) {
						if(this.numCredits == otherCourse.numCredits) {
							return true;
						}
					}
				}
			}
		}return false;
	}
	
	public String toString() {
		return String.format("Course: %3s-%3d | Number of Credits: %02d | Graduate/Ungraduate",
				courseDept, courseNum, numCredits, isGraduateCourse);
	}
	
	//compareTo(Course c): int
}
