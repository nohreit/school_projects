package Project1;

public class Student {

}
