package MIDTERM_CODE;

public class PatientException extends Exception{

	public PatientException() {
	}
	
	public PatientException(String e) {
	}
}
