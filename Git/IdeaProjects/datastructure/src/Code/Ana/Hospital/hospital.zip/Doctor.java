package MIDTERM_CODE;

   public class Doctor implements SeesPatients{

	private static int numDoctors=0; //increment inside the constructor
	private String name;
	private int licenseNumber;
	private Patient[] patients;
	
	public Doctor(String name) {
		this.name= name;
		numDoctors++;
		licenseNumber=numDoctors;
		 patients= new Patient[MAX_PATIENTS];
	}
	
	public static int getNumDoctors() {
		return numDoctors;
	}

	public int getLicenseNumber() {
		return licenseNumber;
	}
	
	public String getName() {
		return name;
	}
	
	public int getNumberOfPatients() {
		int counter=0;
		for(int i=0; i<patients.length; i++) {
			if(isPatient(patients[i])) {
				counter++;
			}
		}
		return counter;
	}
	
	@Override
	//fix
	public String toString() {
		String s= String.format("Doctor= name= %20s | license number= %06d | %s", name, licenseNumber, getPatientsAsString());
	//	s+= getPatientsAsString();
		return s;
	}
	
	@Override
	public boolean equals(Object d) {
		if(d instanceof Doctor){
			Doctor otherD = (Doctor)d;
			if(this.name == otherD.name) {
				if(this.getNumberOfPatients() == otherD.getNumberOfPatients()) {
					return true;
				}
			 }
		
	    } return false;
    }
	//FIX- returns 0 instead of -1
	public int compareTo(Doctor d) {
		Doctor oDoctor= (Doctor)d;
		int comp=0;
		if(this.getNumberOfPatients() > oDoctor.getNumberOfPatients()) {
			comp=1;
		} 
		else if(this.getNumberOfPatients() < oDoctor.getNumberOfPatients()) {
			comp=-1;
		}
		return comp;
	}

	@Override
	//fix
	public void addPatient(Patient p) throws PatientException {
		int counter= Patient.getNumPatients();
		if(isPatient(p)) {	
			for(int i=0; i<counter; i++) {
				patients[counter++]= p;
			}
		}
	}

	@Override
	//fix
	public Patient[] getPatients() {
		return patients;
	}

	@Override
	//fix
	public String getPatientsAsString() {
		String s= "patients= ";
		int numPat= getNumberOfPatients();
		for(int i=0; i<numPat; i++) {
			s+= patients[i].toString()+ (i != numPat ? "," : "");
		}
		return s;
	}

	@Override
	public boolean isPatient(Patient p) {
		int i=0;
		boolean found= false;
		while(i<patients.length && found) {
			if((super.equals(patients[i])== super.equals(p)) ) {
				found=true;
			}
			else {
				i++;
			}
		}
		return found;
	}
	
}
