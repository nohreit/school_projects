package Code.Ana.Trip.vehicleproject;

public interface Announcements {

	public String departure();
	public String arrival();
	public String doNotDisturbTheDriver();
}
