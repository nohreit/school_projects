//package Project1;

//Youtube video: https://youtu.be/DSwa-TPFy58


import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;
public class Driver_SchoolDB {

public static final String MY_FILE_NAME= "SchoolDB_Initial.txt";
	
	public String readFromFile(String fileName) {
		Scanner inStream=null;
		String fileContents="";
		
		try {
			File file= new File(fileName);
			if(file.exists() && file.canRead()) {
			inStream= new Scanner(file);
			while(inStream.hasNextLine()) { 
				fileContents += inStream.nextLine() + "\n"; 
				}
			}
		} catch(FileNotFoundException e) {
			System.err.println("Cannot read from file "+ fileName);
			e.printStackTrace();
		}
		finally {
			if(inStream!=null) {
				inStream.close();
			}
		}
		return fileContents;
	}

	public static String readFile(String fileName) {
		Scanner inStream= null;
		
		String fileCont="";
		String s="";
		String text="";
		ArrayList <Student> students=new ArrayList<Student>();
		ArrayList<Course> courses = new ArrayList<Course>();
		ArrayList<Faculty> faculties=new ArrayList<Faculty>();
		ArrayList<GeneralStaff> genStaff= new ArrayList<GeneralStaff>();
		
		try {
			File file= new File(fileName);
			if(file.exists() && file.canRead()) {
			inStream= new Scanner(file);
			
			//String [] info= fileCont.split(",");
				while(inStream.hasNextLine()) {
					String [] info= fileCont.split(",");
					
					//need to count how many parameters does the line has to then see in which constructor the parameter go
						if(fileCont == "Course") {
							boolean g= Boolean.parseBoolean(info[0]);
							
							int num= Integer.parseInt(info[1]);
							
							String course= info[2];
							
							int credits= Integer.parseInt(info[3]);
							
							Course c= new Course(g, num, course, credits);
							
							//courses+= c.toString()+ "\n";
							courses.add(c);
							System.out.print(courses);
						}
						inStream.hasNext();
						if( fileCont == "Faculty") {
							int param=0;
								String name= info[0];
								
								int year= Integer.parseInt(info[1]);
								
								String course= info[2];
								
								boolean tenured= Boolean.parseBoolean(info[3]);
								
//								if(fileCont.isEmpty()) {
//									Faculty f= new Faculty();
//								}
//								if(fileCont == tenured) {
//									Faculty f=new Faculty(tenured);
//								}else if(fileCont.)
								Faculty f= new Faculty(name, year, course, tenured);
										
								faculties.add(f);
								//System.out.println(faculties);
							}
						inStream.hasNext();
						if(fileCont== "Student") {
							String name= info[0];
							
							int year= Integer.parseInt(info[1]);
							
							String course= info[2];
							
							boolean graduate= Boolean.parseBoolean(info[3]);
							
							Student st= new Student(name, year, course, graduate);
										
							 students.add(st);
							// System.out.println(students);
						}
						inStream.hasNext();
						if(fileCont=="GeneralStaff") {
							String name= info[0];
							
							int year= Integer.parseInt(info[1]);
							
							String dep= info[2];
							
							String duty= info[3];
							
							GeneralStaff g= new GeneralStaff(name, year, dep, duty);
										
										
							genStaff.add(g);
							//System.out.println(genStaff);
						}
					}
				}
			
			}
			catch(FileNotFoundException e){
				System.err.println("Cannot read from file "+ fileName);
				e.printStackTrace();
			}
		return s += "COURSES: \n" + courses.toString()+ "GENERAL STAFF: \n"+ genStaff.toString()+ "FACULTY: \n"+faculties.toString()+"STUDENTS: \n"+ students.toString();
		}
	
	public static void readFileDisplayOnConsole(String fileName) {
		Scanner inStream=null;
		try {
			File file= new File(fileName);
			if(file.exists() && file.canRead()) {
			inStream= new Scanner(file);
			while(inStream.hasNextLine()) {
				String theLine = inStream.nextLine();
				System.out.println(theLine);
				}
				
			}
		}catch(FileNotFoundException e) {
				System.err.println("Cannot read from file "+ fileName);
				e.printStackTrace();
	}finally {
		if(inStream != null) {
			inStream.close(); 
		}
	}
	
	}
	
//	public static void readFileCreate(String fileName)throws FileNotFoundException{
//		arraylist= new ArrayList<Course>();
//		File school= new File(fileName);
//		Scanner sc= new Scanner(school);
//		
//		while(sc.hasNextLine()) {
//			try {
//				String [] line= sc.nextLine().split(",");
//				
//			}
//		}
//	}
	
	public static void main(String[]args) {
		
		File f1= new File(MY_FILE_NAME);
		readFileDisplayOnConsole(MY_FILE_NAME);
		
		System.out.println();
		System.out.println("**************************************************************");
		System.out.println("SCHOOL DATABASE INFO:");
		System.out.println();
		System.out.println("**************************************************************");
		System.out.println();
		
		System.out.println(readFile(MY_FILE_NAME));
		
	}
	
}



