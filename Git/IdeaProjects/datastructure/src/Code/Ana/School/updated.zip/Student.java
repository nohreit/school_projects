package Project1;

public class Student extends Person{

	public static int numStudents;
	private int studentID; //generated
	private Course[] coursesTaken;
	private int numCoursesTaken;//controlled
	private boolean isGraduate;
	private String major;
	
	public Student() {
		super();
		coursesTaken= new Course[0];
		this.numCoursesTaken=0;
		this.isGraduate=false;
		this.major="";
		numStudents++;
		this.studentID=numStudents;
	}
	
	public Student(boolean graduate) {
		super();
		coursesTaken= new Course[0];
		this.numCoursesTaken=0;
		setIsGraduate(graduate);
		this.major="";
		numStudents++;
		this.studentID=numStudents;
	}
	
	public Student(String major, boolean graduate) {
		super();
		coursesTaken= new Course[0];
		this.numCoursesTaken=0;
		setIsGraduate(graduate);
		setMajor( major);
		numStudents++;
		this.studentID=numStudents;
	}
	
	public Student(String name, int by, String major, boolean graduate) {
		super(name, by);
		coursesTaken= new Course[0];
		this.numCoursesTaken=0;
		setIsGraduate(graduate);
		setMajor( major);
		numStudents++;
		this.studentID=numStudents;
	}
	
	public boolean isGraduate() {
		if(this.isGraduate==true) {
			return true;
		}else {
			return false;
		}
	}
	
	public int getNumCoursesTaken() {
		return numCoursesTaken;
	}
	
	public static int getNumStudents() {
		return numStudents;
	}
	
	public int getStudentID() {
		return studentID;
	}
	
	public String getMajor() {
		return major;
	}
	
	public void setIsGraduate(boolean graduate) {
		if(graduate==true) {
			System.out.print("Graduate");
		}else {
			System.out.print("Ungraduate");
		}
	}
	
	public String setMajor(String major) {
		this.major=major;
		return this.major;
	}
	
	public void addCourseTaken(Course course) {
		if(isValid(numCoursesTaken)) {
			coursesTaken[numCoursesTaken++]= course;
		}
	}
	
	public void addCoursesTaken(Course[] course) {
		for(int i=0; i<numCoursesTaken; i++) {
			if(isValid(numCoursesTaken)) {
			coursesTaken[numCoursesTaken++]= course[i];
			}
		}
	}
	
	public Course getCourseTaken(int index) {
		if(isValid(index)) {
			return coursesTaken[index];
		}
		return null;	
	}
	
	public String getCourseTakenAsString(int index) {
		if(isValid(index)) {
			return coursesTaken[index].toString();
		}return null;
	}
	
	public String getAllCoursesTakenAsString() {
		String t="";
		for(int i=0; i<numCoursesTaken; i++) {
			 t += getCourseTakenAsString(i) + (i != numCoursesTaken ? "," : "");
		}return t;
	}
	
	public boolean isValid(int index) {
		if(index >0 && index< 100) {
			return true;
		}return false;
	}
	
	@Override 
	public boolean equals(Object s) {
		if(s instanceof Student) {
			Student otherStudent= (Student)s;
			if(super.equals(otherStudent)) {
				if(this.studentID == otherStudent.studentID) {
					if(this.numCoursesTaken == otherStudent.numCoursesTaken) {
						if(this.isGraduate == otherStudent.isGraduate) {
							if(this.major == otherStudent.major) {
								if(this.coursesTaken == otherStudent.coursesTaken) {
									return true;
								}
							}
						}
					}
				}
			}
		}return false;
	}
	
	@Override
	public String toString() {
		String s= super.toString()+ String.format("Student: studentId: %4d| Major %20s | %14s| Number od Courses Taken: %3d | Courses Take: %s",
				studentID, major, isGraduate, numCoursesTaken, getAllCoursesTakenAsString());
		return s;
	}
	
	@Override
	public int compareTo(Person s) {
		if( s instanceof Person) {
			return super.compareTo(s);
		}
		if(getNumCredits() < ((Student)s).getNumCredits()) {
			return -1;
		}
		if(getNumCredits() > ((Student)s).getNumCredits()) {
			return 1;
		}
		return 0;
	}

}
