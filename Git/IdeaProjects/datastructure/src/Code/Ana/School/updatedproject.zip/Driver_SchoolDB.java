//package Project1;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
public class Driver_SchoolDB {

	public static final String MY_FILE_NAME= "“SchoolDB_Initial.txt”";
	
	public static void main(String[]args) {
		Scanner scnr = new Scanner(System.in);
	//	readFromFile(MY_FILE_NAME);
//		File f1= new File(MY_FILE_NAME);
//		f1.readFileDisplayOnConsole(MY_FILE_NAME);
		
		System.out.println("************************");
		System.out.println("Welcome to the school data base!");
		System.out.println("Do you want to enter information to the system?");
		
		String YesNo="";
		String type="";
		String info="";
		YesNo=scnr.next();
		
		if(YesNo.equalsIgnoreCase("Yes")) {
			System.out.println("Type: Course, Faculty, GeneralStaff, or Student");
			type=scnr.next();
			if(type.equalsIgnoreCase("Course")) {
				System.out.println("Enter Name of course, number of credits. If it is a graduate course enter: true, otherwise enter false");
				info= scnr.next();
			
			}
			
		}
	}

	public String readFromFile(String fileName) {
		Scanner inStream=null;
		String fileContents="";
		
		try {
			File file= new File(fileName);
			if(file.exists() && file.canRead()) {
			inStream= new Scanner(file);
			int lineNum=0;
			while(inStream.hasNextLine()) {
				fileContents += (++lineNum) + " " + inStream.nextLine() + "\n"; 
				fileContents += inStream.nextLine() + "\n"; 
				 
				}
			}
		} catch(FileNotFoundException e) {
			System.err.println("Cannot read from file "+ fileName);
			e.printStackTrace();
		}
		finally {
			if(inStream!=null) {
				inStream.close();
			}
		}
		return fileContents;
	}
	
	public void readFileDisplayOnConsole(String fileName) {
		Scanner inStream=null;
		try {
			File file= new File(fileName);
			if(file.exists() && file.canRead()) {
			inStream= new Scanner(file);
			int lineNum=0;
			while(inStream.hasNextLine()) {
				String theLine= inStream.nextLine();
				System.out.println("the line num: "+(++lineNum)+ ": " + theLine);
				}
				
			}
		}catch(FileNotFoundException e) {
				System.err.println("Cannot read from file "+ fileName);
				e.printStackTrace();
	}finally {
		if(inStream != null) {
			inStream.close(); 
		}
	}
	
	}


}
