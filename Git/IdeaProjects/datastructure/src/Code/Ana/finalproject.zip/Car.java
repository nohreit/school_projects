//package FINAL_CODE;

public class Car extends Vehicle implements Comparable<Car>, Announcements{

	private int numDoors;
	private int numWindows;
	
	public Car(int numDoors, int numWindows) {
		super(2,2);
		this.numDoors= numDoors;
		this.numWindows = numWindows;
	}
	
	public Car(int numDoors, int numWindows, int numSeatsPerRow) {
		super(2,numSeatsPerRow);
		this.numDoors= numDoors;
		this.numWindows= numWindows;
	}
	
	public Car(int numDoors, int numWindows, int [] numSeatsPerRow) {
		super(numSeatsPerRow);
		this.numDoors= numDoors;
		this.numWindows = numWindows;
	}
	
	public Car(int numDoors, int numWindows,Person driver, int [] numSeatsPerRow) throws InvalidDriverException {
		super(driver, numSeatsPerRow);
		this.numDoors= numDoors;
		this.numWindows= numWindows;
	}

	public boolean canOpenDoor(Person p) {
		/**
		 * returns true if the Person is seated in either of 
		 * the exterior seats of a row that has a door 
		 * (column index 0 or last index of that row) and is over age 5.
		 *  It returns false otherwise.
			If the number of doors is less than 2 * numberOfRows, 
			the row/s past numDoors / 2 has/have no doors.
			
			you should be able to use the numberOfSeatsPerRow,  getPeopleOnBoard method and/or the getPeopleInRow method 
			to determine if a Person can open a door based on their location  (column 0 or column  row's length-1)
		 */ 
		boolean openDoor = false;
		Person [][] car= getPeopleOnBoard();
		if(p != null) {
			if(numDoors < (2 * numberOfRows) && (numDoors /2 ) < numberOfRows  ){
				openDoor=false;
			}
			else {
				if(p.getAge() > 5) {
					for(int i=0; i<car.length; i++) { //row
						for(int j=0; j<car[i].length; j++) { //column
							if(car[i][0]== p || car[i][car[i].length-1] == p ) {
								openDoor=true;
							}
						}
					}
				}
			}
		}
		return openDoor;
	}
	
	public boolean canOpenWindow(Person p) {
		/**
		 * returns true if the Person is seated in either 
		 * of the exterior seats of a row that has a window 
		 * (column index 0 or last index of that row) and is over age 2.
		 *  It returns false otherwise. If the number of windows is 
		 *  less than 2 * numberOfRows, the row/s  past numWindows / 2 has/have no windows.

		 */ //p.getAge() > 2
		boolean openWindow=false;
		Person [][] car= getPeopleOnBoard();
		if(p != null) {
			if(numWindows < (2 * numberOfRows) && (numWindows /2 ) < numberOfRows  ){
				openWindow=false;
			}
			else {
				if(p.getAge() > 2) {
					for(int i=0; i<car.length; i++) {
						for(int j=0; j<car[i].length; j++) {
							if(car[i][0] ==p || car[i][car[i].length-1] ==p ) {
								openWindow= true;
							}
						}
					}
				}
			}
		}
		return openWindow;
	}
	
	public int getNumDoors() {
		return numDoors;
	}
	
	public int getNumWindows() {
		return numWindows;
	}
	
	public boolean equals(Object o) {
		if(o instanceof Car) {
			Car otherCar= (Car)o;
			if(this.numDoors== otherCar.numDoors) {
				if(this.numWindows== otherCar.numWindows) {
					if(super.maxSeatsPerRow == otherCar.maxSeatsPerRow) {
						if(super.numberOfRows== otherCar.numberOfRows) {
							if(super.numSeatsPerRow == otherCar.numSeatsPerRow) {
								return true;
							}
						}
					}
				}
					
			}
		}
		return false;
	}
	
	public String toString() {
		String s="";
		String names= "";
		for(int i=0; i<personsOnBoard.length; i++) {
			for(int j=0; j<personsOnBoard[i].length; j++) {
				if(personsOnBoard[i][j] != null) {
					names += personsOnBoard[i][j].getName() + " ";
				}
			}
		}
		s= String.format("Car: number of doors= %02d | number of windows= %02d |"
				+ " number of rows= %02d | seats per row= %s | names of people on board= %s\n", numDoors, numWindows, numberOfRows, numSeatsPerRow, names);
		return s;
	}
	
	@Override
	public int compareTo(Car c) {
		/**
		 * This method returns -1 if the calling object’s total number of seats 
		 * is less than the passed in object’s total number of seats,
		 *  1  if the calling object’s total number of seats is greater than 
		 *  the passed in object’s total number of seats, 0 if they have the 
		 *  same total number of seats.
		 */
		Car otherCar= (Car)c;
		if((super.maxSeatsPerRow * super.numberOfRows) < (otherCar.maxSeatsPerRow * otherCar.numberOfRows)) {
			return -1;
		}
		if((super.maxSeatsPerRow * super.numberOfRows) > (otherCar.maxSeatsPerRow * otherCar.numberOfRows)) {
			return 1;
		}
		else {
			return 0;
		}
	}
	
	@Override
	public String departure() {
		String s= "All Aboard\n";
		return s;
	}

	@Override
	public String arrival() {
		String s= "Everyone out\n";
		return s;
	}

	@Override
	public String doNotDisturbTheDriver() {
		String s= "No Backseat Driving\n";
		return s;
	}

	@Override
	public boolean loadPassenger(Person p) { //FAILED
		if(p != null) { //if person is not null
			for(int row=0; row<personsOnBoard.length; row++) {
				
				for(int col=0; col<personsOnBoard[row].length;col++) { 
					
					if(isSeatEmpty(row,col)) { //if seat is empty
						
						if(row == 0) { //if it is first row
							
							if(p.getAge() >5 || p.getHeight() >36) { //checking if person can be in the 1st row
								
								this.personsOnBoard[row][col]= p; //placing person
								return true;
								
							}
						}
						else { //start at next row
								
							for( row=1; row<personsOnBoard.length;row++) {
									
								for(col=0; col<personsOnBoard[row].length;col++) {
										
									if(isSeatEmpty(row,col)) { 
											
										personsOnBoard[row][col]=p; //placing person
										return true;
									}
								}
							}
						}
							break;
					}
				}
			}
		}
		
		return false;
	}
	private boolean isSeatEmpty(int row, int col) {
		return this.personsOnBoard[row][col]==null;
	}

	@Override
	public int loadPassengers(Person[] peeps) { 
		/**
		 * This method attempts to load as many of the persons specified in the peeps
		 *  array as possible. This method returns the number of people that were loaded 
		 *  into the Vehicle.
		 *  The people will all get placed sitting on top of each other once an empty seat is found the way the loops are. 
		 *  Trace the code by hand and you'll see row increments 1 time, column increments 1 time, 
		 *  peeps increments until its length, before the column loop has a chance to go again.

		 */
		int count=0;
		int row;
		int col;
		int k=0;
		
		if(peeps[k] != null) {
			do {
				for( row=0; row<personsOnBoard.length;row++) {
			
					for(col=0; col< personsOnBoard[row].length;col++) { 
					
						if(isSeatEmpty(row,col)) {
						
							if( row==0) {
								if(peeps[k].getAge() > 5 && peeps[k].getHeight() >36) {
									
									personsOnBoard[row][col]= peeps[k]; //placing person
									count +=1;
								}
							}
							else {
								for( row=1; row<personsOnBoard.length;row++) {
								
									for(col=0; col<personsOnBoard[row].length;col++) {
										
										if(isSeatEmpty(row,col)) { 
											
											personsOnBoard[row][col]= peeps[k]; //placing person
											count +=1;
										}
									}
								}
							}
						}
					k++;
					}
				}
			} while(k<personsOnBoard.length);
		}
		return count;
	}
	
	
}
