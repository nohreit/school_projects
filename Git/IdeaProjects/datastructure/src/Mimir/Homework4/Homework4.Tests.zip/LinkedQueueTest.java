package Mimir.Homework4;

import org.junit.jupiter.api.Test;

import java.util.*;

class LinkedQueueTest<Object> {
    Node<Object> head = null;
    final int maxQueue = 10;
    int numItems = 0;

    @Test
    boolean isEmpty() {
        return numItems == 0;
    }

    @Test
    int size() {
        return numItems;
    }

    @Test
    void enqueue(Object e) throws IllegalStateException, NullPointerException {
        Node<Object> data = new Node<>(e);
        if (e == null) throw new NullPointerException("Null value forbidden");
        else if (size() > maxQueue) throw new IllegalStateException("The queue is full!!");

        if (isEmpty()) this.head = data;
        else {
            Node<Object> item = this.head;
            while (item.getNext() != null) {
                item = item.getNext();
            }
            item.setNext(data);
            data.setPrevious(item);
        }
        this.numItems++;
    }

    @Test
    Object peek() {
        return this.head.getData();
    }

    @Test
    Object dequeue() {
        Object item = peek();
        if (!isEmpty()) {
            this.head = this.head.getNext();
            this.head.setPrevious(null);
        }
        numItems--;
        return item;
    }

    @Test
    Object dequeue(int index) throws NoSuchElementException {
        if (index == 0) {
            Object item = peek();
            dequeue();
            return item;
        } else if (index >= 0 && index < size()) {
            Node<Object> item = this.head;
            int i = 0;
            if (!isEmpty()) {
                while (item.getNext() != null && i++ != index) {
                    item = item.getNext();
                }
                item.getPrevious().setNext(item.getNext());
            }
            numItems--;
            return item.getData();
        } else throw new NoSuchElementException("No such element in the set");
    }

    @Test
    void removeAll() {
        this.head = null;
        this.numItems = 0;
    }

    @Test
    @SuppressWarnings("unchecked")
    void run() {
        for (int i = 0; i < 10; i++) {
            enqueue((Object) ("" + (i + 1)));
        }
        Node<Object> item = this.head;

        println((Object) ("peek => " + peek()));
        println((Object) ("size: " + size()));

        int i = 0;

        while (i++ < size()) {
            print((Object) (item.getPrevious() == null ?
                    "null <= " : item.getPrevious().getData() + " <= "));
            print((Object) (item.getData() + " => "));
            println((Object) (item.getNext() == null ?
                    "null" : item.getNext().getData()));
            item = item.getNext();
        }

        println((Object) ("removed " + dequeue()));
        println((Object) ("peek => " + peek()));
        println((Object) ("removed " + dequeue(0)));
        println((Object) ("peek => " + peek()));
        println((Object) ("size: " + size()));

        item = this.head;

        while (item.getNext() != null) {
            print((Object) (item.getPrevious() == null ?
                    "null <= " : item.getPrevious().getData() + " <= "));
            print((Object) (item.getData() + " => "));
            println((Object) (item.getNext() == null ?
                    "null" : item.getNext().getData()));
            item = item.getNext();
        }
    }

    @Test
    private List<Object> asList(Node<Object> node){
        List<Object> list = new LinkedList<>();
        while (node != null) {
            list.add(node.getData());
            node = node.getNext();
        }
        return list;
    }

    @Test
    Iterator<Object> iterator() {
        return new ElementIterator<>(this.asList(this.head));
    }

    public void println(Object o) {
        System.out.println(o);
    }

    public void print(Object o) {
        System.out.print(o);
    }
}