package Mimir.Homework4;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

class ArrayBasedStackTest<E> {
    Object[] arr = new Object[10];
    int numItems = 0;

    @Test
    boolean isEmpty() {
        return this.numItems == 0;
    }

    @Test
    int size() {
        return this.numItems;
    }

    @Test
    void push(Object e) throws IllegalStateException, NullPointerException {
        if(e != null) arr[numItems++] = e;
        else if (size() == arr.length) throw new IllegalStateException("Array is full");
        else throw new NullPointerException("Null value forbidden");
    }
    
    @Test
    Object peek() {
        if(isEmpty()) return null;
        return this.arr[this.size()-1];
    }

    @Test
    Object pop() {
        Object item = arr[this.size()-1];
        arr[this.size()-1] = null;
        this.numItems--;
        return item;
    }

    @Test
    void clear() {
        arr = new Object[10];
        numItems = 0;
    }

    @Test
    void run(){
        for (int i = 0; i < 10; i++) {
            push(i+1);
        }

        println("Size: "+size());
        println("peek() => "+ peek());

        int j = 0;
        for(Object i:arr) {
            if(i != null) println("item "+(j++)+": "+i);
        }

        println("popped: "+pop());
        println("popped: "+pop());

        println("Size: "+size());
        j = 0;
        for(Object i:arr) {
            if(i != null) println("item "+(j++)+": "+i);
        }

        clear();

        println("Is it empty? : "+this.isEmpty());

    }

    @Test
    Iterator<Object> iterator() {
        return new ElementIterator<>(new ArrayList<>(Arrays.asList(arr)));
    }

    public void println(Object o){
        System.out.println(o);
    }

    public void print(Object o){
        System.out.print(o);
    }
}