package Mimir.Homework4;

import org.junit.jupiter.api.Test;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

class LinkedStackTest<Object> {
    final int maxQueue = 10;
    Node<Object> bottom = null;
    int numItems = 0;

    @Test
    boolean isEmpty() {
        return numItems == 0;
    }

    @Test
    int size() {
        return numItems;
    }

    @Test
    void push(Object e) throws IllegalStateException, NullPointerException{
        Node<Object> data = new Node<>(e);
        if (e == null) throw new NullPointerException("Null value forbidden");
        else if (size() > maxQueue) throw new IllegalStateException("The queue is full!!");

        if (isEmpty()) this.bottom = data;
        else {
            Node<Object> item = this.bottom;
            while (item.getNext() != null) {
                item = item.getNext();
            }
            item.setNext(data);
            data.setPrevious(item);
            this.bottom.setPrevious(data);
        }
        this.numItems++;
    }

    @Test
    Object peek() {
        return this.bottom.getPrevious().getData();
    }

    @Test
    Object pop() {
        Object item = peek();
        if(!isEmpty()){
            this.bottom.setPrevious(this.bottom.getPrevious().getPrevious());
            this.bottom.getPrevious().setNext(this.bottom);
        }
        numItems--;
        return item;
    }

    @Test
    void clear() {
        this.bottom = null;
        this.numItems = 0;
    }

    @Test
    @SuppressWarnings("unchecked")
    void run(){
        for (int i = 0; i < 10; i++) {
            push((Object) ("" + (i + 1)));
        }
        Node<Object> item = this.bottom;
        Iterator<Object> it = this.iterator();

        println((Object) ("peek => " + peek()));
        println((Object) ("size: " + size()));

        item = this.bottom;
        while (item.getNext() != null) {
            print((Object) (item.getPrevious() == null ?
                    "null <= " : item.getPrevious().getData() + " <= "));
            print((Object) (item.getData() + " => "));
            println((Object) (item.getNext() == null ?
                    "null" : item.getNext().getData()));
            item = item.getNext();
        }

//        while(it.hasNext()){
//            println(it.next());
//        }

//        println((Object) ("removed " + pop()));
//        println((Object) ("peek => " + peek()));
//        println((Object) ("removed " + pop()));
//        println((Object) ("peek => " + peek()));
//        println((Object) ("size: " + size()));
//
//        item = this.bottom;
//        i = 0;
//        while (i++ < size()) {
//            print((Object) (item.getPrevious() == null ?
//                    "null <= " : item.getPrevious().getData() + " <= "));
//            print((Object) (item.getData() + " => "));
//            println((Object) (item.getNext() == null ?
//                    "null" : item.getNext().getData()));
//            item = item.getNext();
//        }
//
//        clear();
//
//        println((Object) ("Is it empty? "+isEmpty()+"!"));
    }

    @Test
    private List<Object> asList(Node<Object> node){
        List<Object> list = new LinkedList<>();
        while (node != null) {
            list.add(node.getData());
            node = node.getNext();
        }
        return list;
    }

    @Test
    Iterator<Object> iterator() {
        return new ElementIterator<>(this.asList(this.bottom));
    }

    public void println(Object o) {
        System.out.println(o);
    }

    public void print(Object o) {
        System.out.print(o);
    }
}