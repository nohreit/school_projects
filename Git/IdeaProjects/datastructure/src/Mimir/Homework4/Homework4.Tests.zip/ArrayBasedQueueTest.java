package Mimir.Homework4;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.NoSuchElementException;

class ArrayBasedQueueTest<E> {
    int size = 0;
    Object[] arr = new Object[10];

    @Test
    boolean isEmpty() {
        return size == 0;
    }

    @Test
    int size() {
        return this.size;
    }

    @Test
    void enqueue(Object e) throws IllegalStateException, NullPointerException{
        if(e != null) arr[size++] = e;
        else if (size() == arr.length) throw new IllegalStateException("Array is full");
        else throw new NullPointerException("Null value forbidden");
    }

    @Test
    Object peek() {
        if (isEmpty()) return null;
        return arr[0];
    }

    @Test
    Object dequeue() {
        Object item = null;
        if(!isEmpty()){
            item = peek();
            if (size >= 0) System.arraycopy(arr, 1, arr, 0, size);
            arr[size-1] = null;
        }
        size--;
        return item;
    }

    @Test
    Object dequeue(int index) throws NoSuchElementException {
        if(index >= 0 && index < size) {
            Object item = arr[index];
            if(!isEmpty()){
                if (size - index >= 0) System.arraycopy(arr, index + 1,
                        arr, index, size - index);
                arr[size-1] = null;
            }
            size--;
            return item;
        }else throw new NoSuchElementException("No such element in the set");
    }

    @Test
    void removeAll() {
        arr = new Object[10];
        size = 0;
    }

    @Test
    Iterator<Object> iterator(){
        return new ElementIterator<>(new ArrayList<>(Arrays.asList(arr)));
    }
    @Test
    void run(){
        for (int i = 0; i < 5; i++) {
            enqueue(i+1);
        }

        enqueue("hello world");
        println("Size: "+size());
        println("peek() => "+ peek());

        int j = 0;
        for(Object i:arr) {
            if(i != null) println("item "+(j++)+": "+i);
        }

        println("removing item "+0+": "+dequeue());
        println("peek() => "+ peek());
        println("removing item "+0+": "+dequeue());
        println("removing item "+0+": "+dequeue(3));
//        println("removing item "+0+": "+dequeue(4));

        println("Size: "+size());
        j = 0;
        for(Object i:arr) {
            if(i != null) println("item "+(j++)+": "+i);
        }

        removeAll();

        println("Is it empty? : "+this.isEmpty());
    }

    public void println(Object o){
        System.out.println(o);
    }

    public void print(Object o){
        System.out.print(o);
    }
}